//----------Anvil----------//
    Created By    : PagDev
    License       : CC-BY
    Tools         : Blender 2.78
    Model Version : 1.0

//----------Features----------//
    Vertices      : 152
    Polygons      : 284
    Materials     : 1
    Textures      : 2
    Texture Size  : 1024 x 1024
    Texture Maps  : Diffuse / Specular
    Game Ready    : Yes
    LODs          : No

//----------Package Contains----------//
    Formate       : .blend / .3ds / .obj
    Texturen      : Diffuse Map / Normal Map / Specular Map
    Others        : Preview / Read me

    https://pagdev.de.cool
    https://creativecommons.org/licenses/by/4.0/
